from .BitFieldFactory import Segment
from .BitFieldFactory import new_class

# Import the only 2 interesting things about this package
# so that users don't have to
